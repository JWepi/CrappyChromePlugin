# CrappyChromePlugin
Just a random plugin (extension) as an experiment for google chrome
